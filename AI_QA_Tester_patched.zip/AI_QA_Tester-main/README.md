# AI QA Tester

AI QA Tester is a URL-based black-box QA prototype for small teams without a dedicated QA function. It collects deterministic evidence from a running web app, then uses AI to turn that evidence into prioritized bugs and improvements that a developer can act on.

## Why this approach

Three approaches were considered:

1. **URL-based black-box testing** — easy to adopt, no source-code access required, and closest to the user's view of the product.
2. **Repository/source-code analysis** — can inspect internal logic, but cannot prove that a suspected code issue is visible in the running product.
3. **Hybrid source + live testing** — potentially the most complete, but too broad and integration-heavy for a narrow internship prototype.

This prototype chooses the first option and deliberately separates **evidence collection** from **AI judgement**. The scanner gathers facts; AI decides which facts are meaningful QA findings and how to explain them.

## What the current prototype does

- Accepts a public HTTP(S) URL.
- Fetches the target page plus up to 4 discovered internal pages.
- Checks up to 30 discovered links.
- Records evidence such as HTTP status, response time, selected security headers, headings, forms, missing accessible labels, missing image alt attributes and mixed-content references.
- Promotes clear deterministic failures (for example 404/410/5xx links) as **verified** findings.
- Uses AI to review the remaining evidence and produce additional **bug** and **improvement** findings.
- Shows severity, confidence, evidence, impact, suggested fix and reproduction steps.
- Lets the user dismiss false positives and export the report as Markdown.

## Important scope / limitations

This version is intentionally narrow. It is **not** a full browser agent yet.

- It does not click buttons, type into forms, execute login/checkout flows or verify JavaScript behaviour after interaction.
- It analyzes server-returned HTML, so heavily client-rendered apps may provide less evidence.
- Response timing is a server-fetch signal, not a full browser performance audit.
- Accessibility and security findings are lightweight signals, not formal audits or penetration tests.
- The scan is capped at 5 pages and 30 link checks to keep a live demo fast and predictable.

A natural next step would be adding Playwright-based browser interaction so AI can choose and execute user flows, then compare expected vs actual behaviour.

## Requirements

- Node.js 20+
- npm
- An OpenAI API key

## Local development

```sh
npm install
cp .env.example .env
npm run dev
```

Then open the local URL printed by Vite (normally `http://localhost:3000`).

## Environment variables

Create a `.env` file from `.env.example` and set:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-6-luna
```

`OPENAI_MODEL` is optional; it defaults to `gpt-6-luna`.

## Scripts

```sh
npm run dev       # start the development server
npm run build     # create a production build
npm run preview   # preview the production build
npm run lint      # run ESLint
npm test          # run tests
```
